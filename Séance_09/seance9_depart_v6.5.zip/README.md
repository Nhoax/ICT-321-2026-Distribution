# TimeTrack v6.5 - intervention finale : observabilité et échelle

Dernier acte du mandat. Deux ajouts, presque aucun code : le système
que vous avez construit est déjà prêt pour l'échelle, il ne le sait
simplement pas encore.

## Mission A : le bilan de santé (api/server.js)

Un endpoint GET /health qui vérifie les dépendances vitales (base,
cache) et répond 200 { statut, instance } ou 503. Le TODO vous
guide. Remarquez qu'il n'exige PAS de jeton, et demandez-vous
pourquoi (la réponse est dans le commentaire).

Test : une fois Traefik en place (Mission B), http://localhost/health
répond directement ; et l'en-tête de l'interface affiche l'instance
qui vous sert.

## Mission B : le répartiteur Traefik (compose.yaml)

Deux TODO : le service traefik lui-même, et les trois labels
manquants sur l'API. Le port 3000 n'est PLUS publié : tout passe
par Traefik sur le port 80.

NOTE : le Portier arrive préconfiguré. Le realm chronos (comptes,
client timetrack, rôles) est importé automatiquement au premier
démarrage, et les adresses de confiance du client incluent déjà
http://localhost/* (l'application répond désormais sans :3000,
derrière Traefik). Retenez le principe : dans la vraie vie, une
modification d'infrastructure entraîne une modification de la
configuration d'identité ; ici, elle a été faite pour vous dans
keycloak/chronos-realm.json.

Comptes : jvermot/compta123, cdubois/audit456 (employe),
msandoz/ressources789 (rh) ; console d'administration : admin/admin.

## Le grand moment : passer à l'échelle

```
docker compose up -d --build --scale api=3
```

1. http://localhost/app : connectez-vous. En haut à droite :
   « instance : a1b2c3... ». Rechargez la page plusieurs fois :
   l'instance CHANGE. Le round-robin, sous vos yeux.
2. Tableau de bord Traefik : http://localhost:8090 : vos trois
   cibles sont là, découvertes automatiquement.
3. `docker compose ps` pour repérer les noms des trois instances,
   puis tuez-en une : `docker stop <nom>`. Rechargez la page :
   AUCUNE erreur, les deux survivantes absorbent tout.
4. Question de synthèse (mise en commun) : pourquoi cela
   fonctionne-t-il sans rien casser ? Où sont les sessions ? Le
   cache ? Les données ? Les travaux en attente ? Répondez
   composant par composant : c'est la rétrospective du module.

## Pour les rapides

- Scalez le travailleur aussi (`--scale travailleur=2`) et injectez
  des saisies : observez dans les logs QUI consomme quoi. Le broker
  distribue les messages entre les consommateurs d'une même file.
- Ajoutez un healthcheck Docker au service api dans le compose
  (voir la documentation Compose : healthcheck / test / interval).

## Règle d'or : après TOUTE modification du code

```
docker compose up -d --build
```

Sans --build, le conteneur continue de servir l'ANCIENNE version du
code, copiée dans l'image au moment du dernier build (COPY . .).
Symptôme classique : « ma modification n'a aucun effet ». Pensez
aussi au Ctrl+F5 côté navigateur pour les fichiers du client.
