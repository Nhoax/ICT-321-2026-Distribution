# TimeTrack

App de saisie du temps pour Chronos & Associés.

## Installation

```
npm install
node server.js
```

Ensuite aller sur http://localhost:3000

## Remarques

- La base de données se crée toute seule (fichier timetrack.db)
- Se connecter avec n'importe quel nom (ex: jvermot, cdubois, mfavre)
- Le récapitulatif est un peu lent, c'est normal
- Ne pas toucher au code, ça marche

Le stagiaire, août 2019
