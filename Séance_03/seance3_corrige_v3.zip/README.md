# TimeTrack v3 - CORRIGÉ de la séance 3

L'équipe de développement a migré le code vers PostgreSQL pendant la
semaine (la base retenue pour le groupe après la fusion). L'ancienne
interface du stagiaire est archivée : place à la nouvelle, seule au
monde désormais (http://localhost:3000/app une fois que ça tourne).

Mais essayez donc de lancer `node server.js`... Le code est prêt,
l'infrastructure n'existe pas. C'est votre mission.

## Mission A : conteneuriser l'API

Complétez le `Dockerfile` (les TODO vous guident), puis :

```
docker build -t timetrack-api .
docker run -p 3000:3000 timetrack-api
```

Observez le résultat. Que disent les logs ? Pourquoi ? Notez votre
diagnostic : il servira à la mise en commun.

## Mission B : orchestrer le système

Complétez `compose.yaml` (services api + db), puis :

```
docker compose up --build
```

Rappel du jour : entre conteneurs, localhost n'existe pas. Chaque
service porte un nom, et ce nom est son adresse.

## Mission C : des données qui survivent

1. Saisissez quelques heures dans l'interface.
2. `docker compose down` puis `docker compose up`
3. Vos saisies ont-elles survécu ? Pourquoi ?
4. Ajoutez le volume nommé (TODO dans compose.yaml) et recommencez.
5. Testez enfin `docker compose down -v`. Conclusion ?

## Pour les rapides : le sabotage

Changez PGHOST en `localhost` (ou un nom farfelu), relancez, et
diagnostiquez la panne uniquement avec `docker compose logs api`.
Remettez ensuite les choses en ordre, évidemment.

## Commandes de survie

```
docker compose up --build     # construire et démarrer tout
docker compose up -d          # pareil, en arrière-plan
docker compose ps             # qui tourne ?
docker compose logs -f api    # suivre les logs d'un service
docker compose down           # tout arrêter
docker compose down -v        # tout arrêter ET détruire les volumes (!)
```

## Règle d'or : après TOUTE modification du code

```
docker compose up -d --build
```

Sans --build, le conteneur continue de servir l'ANCIENNE version du
code, copiée dans l'image au moment du dernier build (COPY . .).
Symptôme classique : « ma modification n'a aucun effet ». Pensez
aussi au Ctrl+F5 côté navigateur pour les fichiers du client.
