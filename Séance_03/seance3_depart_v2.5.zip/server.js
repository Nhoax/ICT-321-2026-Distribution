// ============================================================
// TimeTrack v2.5 - migration PostgreSQL
// Mandat Chronos & Associés, intervention n°3
//
// L'équipe de développement a migré le code de SQLite vers
// PostgreSQL (la base retenue pour le groupe après la fusion).
// L'ancienne interface du stagiaire a été archivée : la nouvelle
// interface (dossier public/) est désormais la seule.
//
// ATTENTION : ce code est prêt, mais il lui faut son
// infrastructure. Sans base PostgreSQL joignable, il ne démarre
// pas. C'est votre mission (voir README.md).
// ============================================================

const express = require('express');
const { Pool } = require('pg');

const app = express();
app.use(express.json());
app.use('/app', express.static('public'));

// Le Pool lit sa configuration dans les variables d'environnement :
// PGHOST, PGUSER, PGPASSWORD, PGDATABASE (et PGPORT, 5432 par défaut).
const pool = new Pool();

const PROJECTS = ['Comptabilité Muller SA', 'Audit Fiduciaire Perret', 'Fiscalité privés', 'Administration interne'];

// ---------- initialisation de la base ----------

async function initDb() {
  // La base peut mettre quelques secondes à démarrer (surtout dans un
  // conteneur fraîchement créé) : on réessaie plutôt que de planter.
  // Première graine de « design for failure », on en reparlera...
  for (let essai = 1; essai <= 10; essai++) {
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS entries (
          id SERIAL PRIMARY KEY,
          username TEXT NOT NULL,
          date TEXT NOT NULL,
          project TEXT NOT NULL,
          hours REAL NOT NULL,
          description TEXT
        )
      `);
      console.log('Base de données prête.');
      await seedSiVide();
      return;
    } catch (err) {
      console.log(`Base pas encore joignable (essai ${essai}/10) : ${err.message}`);
      await new Promise(r => setTimeout(r, 2000));
    }
  }
  console.error('Impossible de joindre la base de données. Le serveur s\'arrête.');
  process.exit(1);
}

async function seedSiVide() {
  const { rows } = await pool.query('SELECT COUNT(*)::int AS n FROM entries');
  if (rows[0].n > 0) return;

  const demo = [
    ['jvermot', '2019-08-12', 'Comptabilité Muller SA', 3.5, 'Saisie des pièces comptables T2'],
    ['jvermot', '2019-08-12', 'Administration interne', 1, 'Séance équipe du lundi'],
    ['jvermot', '2019-08-13', 'Comptabilité Muller SA', 4, 'Bouclement intermédiaire'],
    ['jvermot', '2019-08-14', 'Fiscalité privés', 2.5, 'Déclarations en retard (encore)'],
    ['cdubois', '2019-08-12', 'Audit Fiduciaire Perret', 6, 'Contrôle des écritures 2018'],
    ['cdubois', '2019-08-13', 'Audit Fiduciaire Perret', 5.5, 'Suite du contrôle + rapport'],
    ['cdubois', '2019-08-14', 'Administration interne', 2, 'Rangement archives sous-sol'],
    ['cdubois', '2019-08-15', 'Fiscalité privés', 3, 'RDV client Mme Jeanneret'],
    ['mfavre', '2019-08-12', 'Fiscalité privés', 4, 'Déclarations frontaliers'],
    ['mfavre', '2019-08-13', 'Comptabilité Muller SA', 2, 'Coup de main à Julie'],
    ['mfavre', '2019-08-14', 'Fiscalité privés', 5, 'Déclarations frontaliers (suite)'],
    ['mfavre', '2019-08-15', 'Administration interne', 1.5, 'Mise à jour du site web'],
  ];
  for (const d of demo) {
    await pool.query(
      'INSERT INTO entries (username, date, project, hours, description) VALUES ($1, $2, $3, $4, $5)', d
    );
  }
  console.log('Données de démonstration injectées.');
}

// ---------- fonctions utiles (héritées, à moderniser un jour) ----------

// Toujours le cookie en clair du stagiaire. La direction a demandé
// « quelque chose de plus sérieux », c'est prévu dans une intervention
// ultérieure du mandat.
function getUser(req) {
  const cookie = req.headers.cookie || '';
  for (const part of cookie.split(';')) {
    const p = part.trim();
    if (p.startsWith('user=')) return decodeURIComponent(p.substring(5));
  }
  return null;
}

// Toujours la formule « trouvée sur un forum » du stagiaire.
function weekOf(dateStr) {
  const d = new Date(dateStr);
  const jan1 = new Date(d.getFullYear(), 0, 1);
  return Math.ceil((((d - jan1) / 86400000) + jan1.getDay() + 1) / 7);
}

// ---------- authentification (provisoire !) ----------

app.post('/api/login', (req, res) => {
  const { username } = req.body;
  if (!username || !username.trim()) {
    return res.status(400).json({ erreur: 'Nom d\'utilisateur requis' });
  }
  res.setHeader('Set-Cookie', 'user=' + encodeURIComponent(username.trim()) + '; Path=/');
  res.json({ utilisateur: username.trim() });
});

app.post('/api/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'user=; Path=/; Max-Age=0');
  res.status(204).end();
});

app.get('/api/moi', (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });
  res.json({ utilisateur: user });
});

// ---------- API saisies ----------

app.get('/api/saisies', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const { rows } = await pool.query(
    'SELECT * FROM entries WHERE username = $1 ORDER BY date DESC', [user]
  );

  let saisies = rows;
  if (req.query.semaine) {
    saisies = saisies.filter(e => weekOf(e.date) == req.query.semaine);
  }
  res.json(saisies);
});

app.post('/api/saisies', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const { date, project, hours, description } = req.body;

  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return res.status(400).json({ erreur: 'Date manquante ou invalide (format attendu AAAA-MM-JJ)' });
  }
  if (!PROJECTS.includes(project)) {
    return res.status(400).json({ erreur: 'Projet inconnu' });
  }
  const h = Number(hours);
  if (!Number.isFinite(h) || h < 0.5 || h > 24) {
    return res.status(400).json({ erreur: 'Heures invalides (entre 0.5 et 24)' });
  }

  const { rows } = await pool.query(
    'INSERT INTO entries (username, date, project, hours, description) VALUES ($1, $2, $3, $4, $5) RETURNING *',
    [user, date, project, h, description || '']
  );
  res.status(201).json(rows[0]);
});

app.delete('/api/saisies/:id', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const resultat = await pool.query(
    'DELETE FROM entries WHERE id = $1 AND username = $2', [req.params.id, user]
  );
  if (resultat.rowCount === 0) {
    return res.status(404).json({ erreur: 'Saisie introuvable' });
  }
  res.status(204).end();
});

// ---------- totaux ----------
// La « double vérification d'intégrité » exigée par la direction est
// toujours là (et toujours lente). Correctif prévu : intervention n°4.
app.get('/api/totaux', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const totaux = {};
  for (const p of PROJECTS) {
    const { rows } = await pool.query('SELECT * FROM entries WHERE username = $1', [user]);
    let t = 0;
    for (const e of rows) {
      const check = Date.now() + 60;
      while (Date.now() < check) { /* vérification en cours */ }
      if (e.project === p) t += e.hours;
    }
    totaux[p] = t;
  }
  res.json(totaux);
});

// ---------- récapitulatif hebdomadaire ----------
// Repris tel quel de l'ancien système : la mise en page est complexe,
// la génération prend du temps, c'est comme ça (dixit le stagiaire).
app.get('/api/recap', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).send('Non authentifié');

  // génération du document (c'est long mais c'est normal)
  const fin = Date.now() + 4000;
  while (Date.now() < fin) { /* on attend que ça génère */ }

  const { rows } = await pool.query(
    'SELECT * FROM entries WHERE username = $1 ORDER BY date', [user]
  );
  const semaines = {};
  for (const e of rows) {
    const w = weekOf(e.date);
    if (!semaines[w]) semaines[w] = [];
    semaines[w].push(e);
  }

  let contenu = '';
  for (const w of Object.keys(semaines)) {
    let t = 0;
    let lignes = '';
    for (const e of semaines[w]) {
      t += e.hours;
      lignes += `<tr><td>${e.date}</td><td>${e.project}</td><td>${e.hours}</td><td>${e.description}</td></tr>`;
    }
    contenu += `<h2>Semaine ${w} (total : ${t} h)</h2>
<table><tr><th>Date</th><th>Projet</th><th>Heures</th><th>Description</th></tr>${lignes}</table><br>`;
  }

  res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TimeTrack - Récapitulatif</title>
<style>
  body { font-family: Georgia, serif; margin: 30px; }
  table { border-collapse: collapse; width: 100%; }
  td, th { border: 1px solid #888; padding: 4px 8px; font-size: 12px; }
  th { background: #eee; }
</style></head>
<body>
<h1>Récapitulatif hebdomadaire - ${user}</h1>
<p>Chronos &amp; Associés - document à imprimer et signer pour les RH</p>
${contenu}
</body></html>`);
});

// ---------- démarrage ----------

initDb().then(() => {
  app.listen(3000, () => {
    console.log('TimeTrack v2.5 démarré sur http://localhost:3000/app');
  });
});
