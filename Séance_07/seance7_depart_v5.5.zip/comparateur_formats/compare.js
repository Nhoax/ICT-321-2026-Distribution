// ============================================================
// JSON contre protobuf : le même événement, deux sérialisations
// Usage : npm install puis node compare.js
// ============================================================

const protobuf = require('protobufjs');

// L'événement « saisie créée », tel que l'API le publie
const evenement = {
  utilisateur: 'jvermot',
  projet: 'Comptabilité Muller SA',
  heures: 3.5,
  description: 'Saisie des pièces comptables T2',
  creeLe: 1783602150,
};

// Le schéma protobuf : un CONTRAT, comme OpenAPI mais binaire.
// (Chaque champ a un numéro : c'est lui qui voyage, pas le nom.)
const schema = `
syntax = "proto3";
message SaisieCreee {
  string utilisateur = 1;
  string projet = 2;
  double heures = 3;
  string description = 4;
  uint64 creeLe = 5;
}`;

const racine = protobuf.parse(schema).root;
const SaisieCreee = racine.lookupType('SaisieCreee');

// ---------- sérialisations ----------
const enJson = Buffer.from(JSON.stringify(evenement));
const enProto = Buffer.from(SaisieCreee.encode(SaisieCreee.create(evenement)).finish());

console.log('=== Le même événement, deux formats ===\n');

console.log(`JSON      : ${enJson.length} octets`);
console.log('  ' + enJson.toString());
console.log();
console.log(`protobuf  : ${enProto.length} octets  (${Math.round(100 - enProto.length / enJson.length * 100)} % plus compact)`);
console.log('  ' + enProto.toString('hex').replace(/(..)/g, '$1 ').trim());
console.log();

// ---------- et dans l'autre sens ----------
console.log('=== Désérialisation protobuf (avec le schéma) ===');
console.log(SaisieCreee.decode(enProto).toJSON());
console.log();

console.log('=== À méditer ===');
console.log('- JSON : lisible par un humain, auto-descriptif, natif en JS.');
console.log('- protobuf : compact, rapide, typé... mais ILLISIBLE sans le');
console.log('  schéma. Le .proto devient un contrat à partager, comme');
console.log('  OpenAPI. Sans lui, les octets ci-dessus sont muets.');
console.log('- À notre échelle (quelques messages/s), JSON suffit largement.');
console.log('  À l\'échelle de millions de messages : chaque octet compte.');
