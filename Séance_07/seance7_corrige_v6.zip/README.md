# TimeTrack v5.5 - intervention n°7 : l'asynchrone

Le grief du jour : le récapitulatif qui gèle TOUT le monde pendant
4 secondes (vous l'avez chronométré vous-mêmes à l'audit). Verdict
de l'équipe : plus RIEN de lent ne s'exécutera dans l'API. Elle
PUBLIE des événements ; un second service métier (travailleur/) les
consomme et fait le travail lent dans son coin.

Nouvelle structure : api/ et travailleur/ sont deux services
distincts, chacun avec son Dockerfile. Le compose racine orchestre
le tout.

## Mission A : le broker

Complétez compose.yaml : service « broker » (rabbitmq:3-management-
alpine, ports 5672 et 15672) et les depends_on. Puis
`docker compose up --build`. Visitez http://localhost:15672
(guest / guest) : l'onglet Queues sera votre meilleur ami.

## Mission B : publier (api/server.js)

À la création d'une saisie : publier l'événement 'saisie.creee'
(la fonction publier() est fournie, à vous de l'appeler au bon
endroit avec les bonnes données). Vérifiez dans l'interface
RabbitMQ : l'échange « evenements » reçoit vos messages... mais
aucune file ne les récupère encore.

## Mission C : consommer (travailleur/index.js)

Le guichet des notifications : file durable, abonnement au motif
« saisie.* », consommation avec acquittement. Le TODO vous guide.
Test : saisissez des heures, regardez les logs du travailleur
(`docker compose logs -f travailleur`).

## Mission D : la demande de récapitulatif (api/server.js)

Publiez 'recap.demande' dans POST /api/recap/demande (le reste du
circuit est fourni : le travailleur génère et dépose dans Redis,
le client vient chercher). Test : cliquez « Récapitulatif »...
et pendant les 4 secondes de préparation, continuez à saisir des
heures. PERSONNE n'est gelé. Grief officiellement coché.

## Le test de résilience (le clou du spectacle)

1. `docker compose stop travailleur`  (le consommateur meurt)
2. Saisissez 3 ou 4 heures et demandez un récapitulatif : tout
   répond instantanément. Dans l'interface RabbitMQ : les messages
   s'ACCUMULENT dans les files. Rien n'est perdu.
3. `docker compose start travailleur` : regardez les logs. Tout ce
   qui attendait est traité, dans l'ordre.
Un service peut mourir sans rien casser ni rien perdre : c'est ça,
le découplage temporel.

## L'expérience de l'acquittement oublié

Commentez le canal.ack(message) de votre mission C, relancez,
saisissez UNE heure... et observez les logs, puis l'interface
RabbitMQ (message « unacked »). Redémarrez le travailleur :
le message revient ! Le broker ne lâche jamais une promesse
non tenue. Remettez le ack, évidemment.

## Bonus : node comparateur_formats/compare.js

Le même événement en JSON et en protobuf : tailles et contenus
côte à côte. De quoi nourrir le débat lisibilité contre compacité.

## Le Portier arrive préconfiguré

Nouveauté de cette intervention : le realm chronos (comptes et rôles
de la séance 6) est livré DANS le projet, en fichier de configuration
(keycloak/chronos-realm.json). Au premier démarrage, Keycloak
l'importe tout seul : aucune reconfiguration à la main. Les comptes :
jvermot / compta123, cdubois / audit456, msandoz / ressources789.
(La configuration d'un composant est du code comme un autre : elle
se versionne et voyage avec le projet.)

## Règle d'or : après TOUTE modification du code

```
docker compose up -d --build
```

Sans --build, le conteneur continue de servir l'ANCIENNE version du
code, copiée dans l'image au moment du dernier build (COPY . .).
Symptôme classique : « ma modification n'a aucun effet ». Pensez
aussi au Ctrl+F5 côté navigateur pour les fichiers du client.
