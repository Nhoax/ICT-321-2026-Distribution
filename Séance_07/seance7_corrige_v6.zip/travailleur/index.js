// ============================================================
// TimeTrack - service TRAVAILLEUR
// Deuxième service métier du système : il ne sert AUCUNE page,
// n'écoute AUCUN port. Il consomme des événements et fait le
// travail lent, dans son coin. S'il bloque 4 secondes, il ne
// bloque que lui : c'est toute la beauté de la chose.
// ============================================================

const amqp = require('amqplib');
const { Pool } = require('pg');
const Redis = require('ioredis');

const pool = new Pool(); // mêmes variables PG* que l'API
const redis = new Redis({ host: process.env.REDIS_HOST || 'localhost' });
redis.on('error', (err) => console.log('Redis :', err.message));

// Toujours la formule « trouvée sur un forum » (elle nous suivra
// jusqu'au bout, celle-là).
function weekOf(dateStr) {
  const d = new Date(dateStr);
  const jan1 = new Date(d.getFullYear(), 0, 1);
  return Math.ceil((((d - jan1) / 86400000) + jan1.getDay() + 1) / 7);
}

async function demarrer() {
  // Connexion au broker (avec la patience désormais habituelle)
  let canal = null;
  for (let essai = 1; essai <= 10; essai++) {
    try {
      const connexion = await amqp.connect(`amqp://${process.env.RABBIT_HOST || 'localhost'}`);
      canal = await connexion.createChannel();
      await canal.assertExchange('evenements', 'topic', { durable: true });
      console.log('Travailleur connecté au broker.');
      break;
    } catch (err) {
      console.log(`Broker pas encore joignable (essai ${essai}/10) : ${err.message}`);
      await new Promise(r => setTimeout(r, 2000));
    }
  }
  if (!canal) process.exit(1);

  // ---------- MISSION C (corrigé) : le guichet des notifications ----------
  const q = await canal.assertQueue('notifications', { durable: true });
  await canal.bindQueue(q.queue, 'evenements', 'saisie.*');
  canal.consume(q.queue, (message) => {
    const e = JSON.parse(message.content.toString());
    console.log(`[NOTIFICATION] ${e.utilisateur} a saisi ${e.heures} h sur ${e.projet}`);
    // Ici, un vrai système enverrait un courriel, un message Teams...
    // Nous, on notifie la console : le MÉCANISME est identique.
    canal.ack(message); // promesse tenue : le broker peut oublier ce message
  });

  // ---------- le générateur de récapitulatifs (fourni) ----------
  // La fameuse « mise en page complexe » de 4 secondes a déménagé
  // ici. Elle bloque ce processus, et SEULEMENT ce processus.
  const qRecaps = await canal.assertQueue('recaps', { durable: true });
  await canal.bindQueue(qRecaps.queue, 'evenements', 'recap.demande');
  canal.consume(qRecaps.queue, async (message) => {
    const { utilisateur } = JSON.parse(message.content.toString());
    console.log(`[RECAP] Demande reçue pour ${utilisateur}, génération...`);

    // La génération « complexe » (le travailleur peut se le permettre)
    const fin = Date.now() + 4000;
    while (Date.now() < fin) { /* on attend que ça génère */ }

    const { rows } = await pool.query(
      'SELECT * FROM entries WHERE username = $1 ORDER BY date', [utilisateur]
    );
    const semaines = {};
    for (const e of rows) {
      const w = weekOf(e.date);
      if (!semaines[w]) semaines[w] = [];
      semaines[w].push(e);
    }
    let contenu = '';
    for (const w of Object.keys(semaines)) {
      let t = 0;
      let lignes = '';
      for (const e of semaines[w]) {
        t += e.hours;
        lignes += `<tr><td>${e.date}</td><td>${e.project}</td><td>${e.hours}</td><td>${e.description}</td></tr>`;
      }
      contenu += `<h2>Semaine ${w} (total : ${t} h)</h2>
<table><tr><th>Date</th><th>Projet</th><th>Heures</th><th>Description</th></tr>${lignes}</table><br>`;
    }
    const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TimeTrack - Récapitulatif</title>
<style>
  body { font-family: Georgia, serif; margin: 30px; }
  table { border-collapse: collapse; width: 100%; }
  td, th { border: 1px solid #888; padding: 4px 8px; font-size: 12px; }
  th { background: #eee; }
</style></head>
<body>
<h1>Récapitulatif hebdomadaire - ${utilisateur}</h1>
<p>Chronos &amp; Associés - document à imprimer et signer pour les RH</p>
${contenu}
</body></html>`;

    // Résultat déposé dans Redis, valable 10 minutes
    await redis.set('recap:' + utilisateur, html, 'EX', 600);
    console.log(`[RECAP] Prêt pour ${utilisateur}.`);
    canal.ack(message);
  });

  console.log('Travailleur en attente d\'événements...');
}

demarrer();
