// ============================================================
// TimeTrack v4.5 - nouvelle interface (client)
// Le login n'est PLUS géré ici : le client redirige vers le
// Portier (Keycloak), qui renvoie l'utilisateur avec ses jetons.
// Flux : Authorization Code + PKCE, via l'adaptateur keycloak-js
// (embarqué dans vendor/, pas de CDN).
// Ce fichier est FOURNI COMPLET : aujourd'hui, vos missions sont
// côté Compose (A), console Keycloak (B) et API (C, D).
// ============================================================

import Keycloak from './vendor/keycloak.js';

const PROJETS = ['Comptabilité Muller SA', 'Audit Fiduciaire Perret', 'Fiscalité privés', 'Administration interne'];

// Le Portier, vu du NAVIGATEUR (d'où localhost, pas keycloak)
const keycloak = new Keycloak({
  url: 'http://localhost:8080',
  realm: 'chronos',
  clientId: 'timetrack',
});

// Ce fichier est un module ES : ses constantes sont invisibles depuis
// la console du navigateur. On expose donc keycloak volontairement,
// à des fins pédagogiques (F12 puis keycloak.token pour copier votre
// jeton, keycloak.tokenParsed pour le voir décodé). En production,
// on n'exposerait pas ça.
window.keycloak = keycloak;

// ---------- en-têtes d'authentification ----------
// Avant chaque appel : rafraîchir le jeton s'il expire dans moins
// de 30 secondes, puis le joindre en Authorization: Bearer.
async function enTetes(extra = {}) {
  await keycloak.updateToken(30).catch(() => keycloak.login());
  return { Authorization: 'Bearer ' + keycloak.token, ...extra };
}

// ---------- saisies ----------

async function chargerSaisies(semaine) {
  let url = '/api/saisies';
  if (semaine) url += '?semaine=' + encodeURIComponent(semaine);

  const reponse = await fetch(url, { headers: await enTetes() });
  if (!reponse.ok) {
    afficherErreur(`Le serveur a répondu ${reponse.status}.`);
    return;
  }

  const saisies = await reponse.json();
  const tbody = document.getElementById('liste');
  tbody.innerHTML = '';
  for (const s of saisies) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${s.date}</td><td>${s.project}</td><td>${s.hours}</td><td>${s.description ?? ''}</td><td></td>`;
    const btn = document.createElement('button');
    btn.textContent = 'Supprimer';
    btn.addEventListener('click', async () => {
      const rep = await fetch('/api/saisies/' + s.id, { method: 'DELETE', headers: await enTetes() });
      if (rep.status === 204) {
        chargerSaisies(document.getElementById('filtre').value);
      } else {
        afficherErreur(`Suppression refusée (${rep.status})`);
      }
    });
    tr.lastElementChild.appendChild(btn);
    tbody.appendChild(tr);
  }
}

async function ajouterSaisie() {
  afficherErreur('');

  const nouvelleSaisie = {
    date: document.getElementById('date').value,
    project: document.getElementById('projet').value,
    hours: parseFloat(document.getElementById('heures').value),
    description: document.getElementById('description').value,
  };

  const reponse = await fetch('/api/saisies', {
    method: 'POST',
    headers: await enTetes({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(nouvelleSaisie),
  });

  if (reponse.status === 201) {
    document.getElementById('heures').value = '';
    document.getElementById('description').value = '';
    chargerSaisies();
  } else {
    const corps = await reponse.json().catch(() => ({}));
    afficherErreur(`Refusé par le serveur (${reponse.status}) : ${corps.erreur ?? 'raison inconnue'}`);
  }
}

// ---------- totaux ----------

async function chargerTotaux() {
  const tbody = document.getElementById('totaux');
  const info = document.getElementById('info-totaux');
  tbody.innerHTML = '<tr><td colspan="2">Calcul en cours (vérification d\'intégrité)...</td></tr>';
  info.textContent = '';

  const reponse = await fetch('/api/totaux', { headers: await enTetes() });
  if (!reponse.ok) return;

  const donnees = await reponse.json();
  const totaux = donnees.totaux ?? donnees;

  tbody.innerHTML = '';
  for (const projet of Object.keys(totaux)) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${projet}</td><td>${totaux[projet]} h</td>`;
    tbody.appendChild(tr);
  }

  if (donnees.depuis) {
    const secondes = (donnees.ms / 1000).toFixed(donnees.ms >= 1000 ? 1 : 3);
    info.textContent = donnees.depuis === 'cache'
      ? `Depuis le cache, en ${donnees.ms} ms`
      : `Calculé (vérification d'intégrité comprise) en ${secondes} s`;
    info.style.color = donnees.depuis === 'cache' ? '#2a7a2a' : '#a35b00';
  }
}

// ---------- récapitulatif ----------
// window.open ne sait pas envoyer d'en-tête Authorization : on va
// chercher le HTML nous-mêmes, puis on l'écrit dans un nouvel onglet.
async function ouvrirRecap() {
  const reponse = await fetch('/api/recap', { headers: await enTetes() });
  if (!reponse.ok) {
    afficherErreur(`Récapitulatif refusé (${reponse.status})`);
    return;
  }
  const html = await reponse.text();
  const fenetre = window.open('', '_blank');
  fenetre.document.write(html);
  fenetre.document.close();
}

// ---------- espace RH (mission D) ----------

async function chargerRH() {
  const zone = document.getElementById('zone-rh-resultat');
  const reponse = await fetch('/api/rh/saisies', { headers: await enTetes() });
  if (reponse.status === 403) {
    zone.textContent = 'Accès refusé (403) : réservé au rôle rh. Et c\'est normal si vous êtes employé !';
    zone.style.color = '#a33';
    return;
  }
  if (!reponse.ok) {
    zone.textContent = `Le serveur a répondu ${reponse.status}.`;
    return;
  }
  const saisies = await reponse.json();
  zone.style.color = '#2a7a2a';
  zone.textContent = `${saisies.length} saisies, tous employés confondus. Le rôle rh ouvre la porte.`;
}

// ---------- outils d'audit ----------

async function injecterSaisies() {
  const btn = document.getElementById('btn-seed');
  btn.disabled = true;
  btn.textContent = 'Injection en cours...';
  const rep = await fetch('/api/demo/seed?n=200', { method: 'POST', headers: await enTetes() });
  btn.disabled = false;
  btn.textContent = 'Injecter 200 saisies';
  if (rep.ok) {
    chargerSaisies();
  } else {
    afficherErreur(`Injection refusée (${rep.status})`);
  }
}

// ---------- branchements ----------

function afficherErreur(message) {
  document.getElementById('erreur').textContent = message;
}

function demarrerInterface() {
  const selectProjet = document.getElementById('projet');
  for (const p of PROJETS) {
    const opt = document.createElement('option');
    opt.textContent = p;
    selectProjet.appendChild(opt);
  }

  // Identité et rôles : tout est dans le jeton (décodé par keycloak-js)
  document.getElementById('nom-utilisateur').textContent =
    keycloak.tokenParsed.preferred_username;
  const roles = (keycloak.tokenParsed.realm_access || {}).roles || [];
  document.getElementById('roles-utilisateur').textContent =
    'rôles : ' + (roles.filter(r => !r.startsWith('default-') && !['offline_access', 'uma_authorization'].includes(r)).join(', ') || 'aucun');

  document.getElementById('btn-deconnexion').addEventListener('click', () => keycloak.logout());
  document.getElementById('btn-ajouter').addEventListener('click', ajouterSaisie);
  document.getElementById('btn-totaux').addEventListener('click', chargerTotaux);
  document.getElementById('btn-recap').addEventListener('click', ouvrirRecap);
  document.getElementById('btn-rh').addEventListener('click', chargerRH);
  document.getElementById('btn-seed').addEventListener('click', injecterSaisies);
  document.getElementById('btn-filtrer').addEventListener('click', () => chargerSaisies(document.getElementById('filtre').value));
  document.getElementById('btn-tout').addEventListener('click', () => {
    document.getElementById('filtre').value = '';
    chargerSaisies();
  });

  document.getElementById('contenu').style.display = '';
  chargerSaisies();
  chargerTotaux();
}

// ---------- démarrage : le Portier d'abord ----------
// login-required : pas de jeton ? Direction la page de login de
// Keycloak, qui nous renverra ici une fois l'identité prouvée.
keycloak.init({ onLoad: 'login-required', pkceMethod: 'S256' })
  .then(demarrerInterface)
  .catch((err) => {
    document.body.innerHTML = '<p style="font-family:sans-serif; margin:40px; color:#a33">'
      + 'Impossible de joindre le Portier (Keycloak). Est-il démarré ? '
      + 'Le realm et le client sont-ils configurés (mission B) ?</p>';
    console.error(err);
  });
