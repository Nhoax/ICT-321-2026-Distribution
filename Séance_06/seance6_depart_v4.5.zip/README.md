# TimeTrack v4.5 - intervention n°6 : le Portier professionnel

Le cookie en clair du stagiaire prend sa retraite. La gestion des
identités est déléguée à un composant fini : Keycloak. Le client
redirige vers sa page de login (flux Authorization Code + PKCE,
adaptateur keycloak-js embarqué dans public/vendor/) ; l'API ne fait
plus qu'une chose : vérifier le sceau des jetons qu'il délivre.

## Mission 0 (remise en jambes, avant Keycloak)

Sur le mini-serveur demo_jwt de la séance passée : ajoutez un
endpoint GET /api/comptabilite réservé au rôle « employe ».
Vérifiez : sans jeton -> 401, avec un jeton employé -> 200.

## Mission A : le service Keycloak

Complétez compose.yaml (TODO), puis `docker compose up --build`.
Keycloak met une bonne minute à démarrer la première fois :
`docker compose logs -f keycloak` jusqu'au « started ».

## Mission B : configurer le Portier

Suivez le guide pas-à-pas distribué (realm chronos, client
timetrack, rôles employe / chef_projet / rh, utilisateurs).
Test intermédiaire : http://localhost:3000/app doit vous rediriger
vers la page de login Keycloak. La connexion réussit... puis
l'interface affiche des erreurs 501 : c'est NORMAL, l'API n'a pas
encore de contrôleur de cartes. Missions C et D.

## Mission C : le middleware verifierJeton (server.js)

Le TODO vous guide : extraire le jeton de l'en-tête Authorization,
le vérifier avec jwtVerify (jose) contre les clés publiques du
Portier (JWKS), poser req.utilisateur et req.roles, ou répondre 401.

À méditer : avec le stagiaire, falsifier l'identité prenait 5
secondes. Ici, l'API vérifie une signature RS256 contre la clé
publique de Keycloak. Le secret (la clé privée) ne quitte JAMAIS
le Portier : l'API n'a plus rien à protéger.

## Mission D : l'autorisation par rôle (RBAC)

Complétez exigerRole(role) : la fabrique de middleware qui garde
l'espace RH (/api/rh/saisies). Un employé authentifié mais sans le
rôle rh doit recevoir... 403, pas 401. Si vous hésitez entre les
deux, relisez la fiche mémo : c'est LA distinction de la semaine.

## Scénario de validation finale

1. Connectez-vous en employé : saisies OK, bouton « Espace RH » -> 403.
2. Déconnexion, connexion avec le compte RH : « Espace RH » -> 200.
3. Dans un onglet privé, sans connexion : l'app redirige vers Keycloak.
4. Bonus : copiez votre jeton (console : keycloak.token) dans le
   décodeur de la séance 5. Retrouvez vos rôles dans realm_access.

## Règle d'or : après TOUTE modification du code

```
docker compose up -d --build
```

Sans --build, le conteneur continue de servir l'ANCIENNE version du
code, copiée dans l'image au moment du dernier build (COPY . .).
Symptôme classique : « ma modification n'a aucun effet ». Pensez
aussi au Ctrl+F5 côté navigateur pour les fichiers du client.
