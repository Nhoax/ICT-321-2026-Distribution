// ============================================================
// TimeTrack v4.5 - intervention n°6 : le Portier professionnel
//
// Le cookie en clair du stagiaire prend enfin sa retraite. La
// gestion des identités est déléguée à un composant fini :
// Keycloak. Le client (public/) redirige vers le Portier pour le
// login ; l'API, elle, ne fait plus qu'une chose : VÉRIFIER le
// sceau des jetons que Keycloak délivre. Voir README.md.
// ============================================================

const express = require('express');
const { Pool } = require('pg');
const Redis = require('ioredis');
const { createRemoteJWKSet, jwtVerify } = require('jose');

const app = express();
app.use(express.json());
app.use('/app', express.static('public'));

// Le Pool lit sa configuration dans les variables d'environnement :
// PGHOST, PGUSER, PGPASSWORD, PGDATABASE (et PGPORT, 5432 par défaut).
const pool = new Pool();

// Connexion à Redis. Même principe : le nom d'hôte vient de
// l'environnement (et entre conteneurs, localhost n'existe pas...).
const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  lazyConnect: false,
});
redis.on('error', (err) => console.log('Redis :', err.message));

// ---------- le Portier : Keycloak ----------
// Subtilité de réseau : le MÊME Keycloak a deux adresses.
// - Vue du navigateur (et donc dans le claim « iss » des jetons) :
//   http://localhost:8080
// - Vue de l'API, à l'intérieur du réseau Compose :
//   http://keycloak:8080
const KC_INTERNE = process.env.KEYCLOAK_URL_INTERNE || 'http://localhost:8080';
const KC_ISSUER = process.env.KEYCLOAK_ISSUER || 'http://localhost:8080/realms/chronos';
const KC_REALM = process.env.KEYCLOAK_REALM || 'chronos';

// Les clés PUBLIQUES du Portier (JWKS). Keycloak signe en RS256 :
// clé privée chez lui, clés publiques téléchargeables par tous.
// Plus aucun secret partagé à protéger côté API !
const JWKS = createRemoteJWKSet(
  new URL(`${KC_INTERNE}/realms/${KC_REALM}/protocol/openid-connect/certs`)
);

const PROJECTS = ['Comptabilité Muller SA', 'Audit Fiduciaire Perret', 'Fiscalité privés', 'Administration interne'];

// ---------- initialisation de la base ----------

async function initDb() {
  // La base peut mettre quelques secondes à démarrer (surtout dans un
  // conteneur fraîchement créé) : on réessaie plutôt que de planter.
  // Première graine de « design for failure », on en reparlera...
  for (let essai = 1; essai <= 10; essai++) {
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS entries (
          id SERIAL PRIMARY KEY,
          username TEXT NOT NULL,
          date TEXT NOT NULL,
          project TEXT NOT NULL,
          hours REAL NOT NULL,
          description TEXT
        )
      `);
      console.log('Base de données prête.');
      await seedSiVide();
      return;
    } catch (err) {
      console.log(`Base pas encore joignable (essai ${essai}/10) : ${err.message}`);
      await new Promise(r => setTimeout(r, 2000));
    }
  }
  console.error('Impossible de joindre la base de données. Le serveur s\'arrête.');
  process.exit(1);
}

async function seedSiVide() {
  const { rows } = await pool.query('SELECT COUNT(*)::int AS n FROM entries');
  if (rows[0].n > 0) return;

  const demo = [
    ['jvermot', '2019-08-12', 'Comptabilité Muller SA', 3.5, 'Saisie des pièces comptables T2'],
    ['jvermot', '2019-08-12', 'Administration interne', 1, 'Séance équipe du lundi'],
    ['jvermot', '2019-08-13', 'Comptabilité Muller SA', 4, 'Bouclement intermédiaire'],
    ['jvermot', '2019-08-14', 'Fiscalité privés', 2.5, 'Déclarations en retard (encore)'],
    ['cdubois', '2019-08-12', 'Audit Fiduciaire Perret', 6, 'Contrôle des écritures 2018'],
    ['cdubois', '2019-08-13', 'Audit Fiduciaire Perret', 5.5, 'Suite du contrôle + rapport'],
    ['cdubois', '2019-08-14', 'Administration interne', 2, 'Rangement archives sous-sol'],
    ['cdubois', '2019-08-15', 'Fiscalité privés', 3, 'RDV client Mme Jeanneret'],
    ['mfavre', '2019-08-12', 'Fiscalité privés', 4, 'Déclarations frontaliers'],
    ['mfavre', '2019-08-13', 'Comptabilité Muller SA', 2, 'Coup de main à Julie'],
    ['mfavre', '2019-08-14', 'Fiscalité privés', 5, 'Déclarations frontaliers (suite)'],
    ['mfavre', '2019-08-15', 'Administration interne', 1.5, 'Mise à jour du site web'],
  ];
  for (const d of demo) {
    await pool.query(
      'INSERT INTO entries (username, date, project, hours, description) VALUES ($1, $2, $3, $4, $5)', d
    );
  }
  console.log('Données de démonstration injectées.');
}

// ---------- fonctions utiles (héritées, à moderniser un jour) ----------

// ---------- le contrôle des cartes ----------

// --- MISSION C : le middleware « verifierJeton » ---
// Le client envoie désormais :  Authorization: Bearer <jeton Keycloak>
// À implémenter :
//   1. extraire le jeton de l'en-tête (voir la démo de la séance 5)
//   2. le vérifier avec :  const { payload } = await jwtVerify(token,
//      JWKS, { issuer: KC_ISSUER });
//      (signature RS256 contre les clés publiques + émetteur + expiration,
//       tout est contrôlé d'un coup)
//   3. en cas de succès : poser req.utilisateur =
//      payload.preferred_username et req.roles =
//      (payload.realm_access && payload.realm_access.roles) || [],
//      puis appeler next()
//   4. en cas d'échec (catch) : répondre 401
async function verifierJeton(req, res, next) {
  // TODO Mission C
  res.status(501).json({ erreur: 'Portier pas encore branché (mission C)' });
}

// --- MISSION D : l'autorisation par rôle (RBAC) ---
// Fabrique de middleware : exigerRole('rh') ne laisse passer que les
// porteurs du rôle. ATTENTION au code : 403 (identifié mais pas
// autorisé), PAS 401.
function exigerRole(role) {
  return (req, res, next) => {
    // TODO Mission D
    res.status(501).json({ erreur: 'Contrôle de rôle pas encore branché (mission D)' });
  };
}

// Toujours la formule « trouvée sur un forum » du stagiaire.
function weekOf(dateStr) {
  const d = new Date(dateStr);
  const jan1 = new Date(d.getFullYear(), 0, 1);
  return Math.ceil((((d - jan1) / 86400000) + jan1.getDay() + 1) / 7);
}

// ---------- API saisies ----------

app.get('/api/saisies', verifierJeton, async (req, res) => {
  const user = req.utilisateur;

  const { rows } = await pool.query(
    'SELECT * FROM entries WHERE username = $1 ORDER BY date DESC', [user]
  );

  let saisies = rows;
  if (req.query.semaine) {
    saisies = saisies.filter(e => weekOf(e.date) == req.query.semaine);
  }
  res.json(saisies);
});

app.post('/api/saisies', verifierJeton, async (req, res) => {
  const user = req.utilisateur;

  const { date, project, hours, description } = req.body;

  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return res.status(400).json({ erreur: 'Date manquante ou invalide (format attendu AAAA-MM-JJ)' });
  }
  if (!PROJECTS.includes(project)) {
    return res.status(400).json({ erreur: 'Projet inconnu' });
  }
  const h = Number(hours);
  if (!Number.isFinite(h) || h < 0.5 || h > 24) {
    return res.status(400).json({ erreur: 'Heures invalides (entre 0.5 et 24)' });
  }

  const { rows } = await pool.query(
    'INSERT INTO entries (username, date, project, hours, description) VALUES ($1, $2, $3, $4, $5) RETURNING *',
    [user, date, project, h, description || '']
  );

  // MISSION C (corrigé) : la donnée source a changé, le cache ment,
  // on le détruit. PAR utilisateur : inutile (et injuste) de faire
  // recalculer tous les employés parce qu'UN seul a saisi une heure.
  await redis.del('totaux:' + user);

  res.status(201).json(rows[0]);
});

app.delete('/api/saisies/:id', verifierJeton, async (req, res) => {
  const user = req.utilisateur;

  const resultat = await pool.query(
    'DELETE FROM entries WHERE id = $1 AND username = $2', [req.params.id, user]
  );
  if (resultat.rowCount === 0) {
    return res.status(404).json({ erreur: 'Saisie introuvable' });
  }

  // MISSION C (corrigé) : une suppression change aussi les totaux !
  await redis.del('totaux:' + user);

  res.status(204).end();
});

// ---------- totaux ----------
// La « double vérification d'intégrité » reste (réglementaire).
// Mais rien n'oblige à la refaire si RIEN n'a changé depuis le
// dernier calcul... c'est tout l'objet des missions B et C.
app.get('/api/totaux', verifierJeton, async (req, res) => {
  const user = req.utilisateur;

  const depart = Date.now();
  const cle = 'totaux:' + user;

  // --- MISSION B (corrigé, 1/2) : consulter le frigo avant le magasin ---
  const enCache = await redis.get(cle);
  if (enCache !== null) {
    return res.json({ totaux: JSON.parse(enCache), depuis: 'cache', ms: Date.now() - depart });
  }

  // --- le calcul complet (avec la vérification réglementaire) ---
  const totaux = {};
  for (const p of PROJECTS) {
    const { rows } = await pool.query('SELECT * FROM entries WHERE username = $1', [user]);
    let t = 0;
    for (const e of rows) {
      const check = Date.now() + 60;
      while (Date.now() < check) { /* vérification en cours */ }
      if (e.project === p) t += e.hours;
    }
    totaux[p] = t;
  }

  // --- MISSION B (corrigé, 2/2) : remplir le frigo pour la prochaine fois ---
  // Le TTL d'une heure est une ceinture de sécurité : si une invalidation
  // nous échappe un jour (mission C oubliée sur une future route ?), le
  // mensonge du cache ne durera pas éternellement. Ce n'est PAS une excuse
  // pour bâcler l'invalidation : une heure de totaux faux, ça reste faux.
  await redis.set(cle, JSON.stringify(totaux), 'EX', 3600);

  res.json({ totaux, depuis: 'calcul', ms: Date.now() - depart });
});

// --- MISSION C : le cache qui ment ---
// Faites le test AVANT de coder : chargez les totaux (mission B
// active), ajoutez une saisie, rechargez les totaux. Alors ?
// Un cache doit être INVALIDÉ quand la donnée source change.
// À vous d'ajouter, dans POST /api/saisies et DELETE /api/saisies/:id
// ci-dessus, la ligne qui supprime la clé :
//   await redis.del('totaux:' + user);
// Question de synthèse : pourquoi PAR utilisateur et pas tout Redis ?

// ---------- outil d'audit (à retirer en production, évidemment) ----------
// Injecte n saisies aléatoires pour l'utilisateur connecté, afin de
// simuler plusieurs mois d'utilisation réelle. Fourni par la société
// d'audit dans le cadre du mandat.
app.post('/api/demo/seed', verifierJeton, async (req, res) => {
  const user = req.utilisateur;

  const n = Math.min(parseInt(req.query.n || '200', 10), 1000);
  const descriptions = [
    'Saisie des pièces comptables', 'Contrôle des écritures', 'Préparation du bouclement',
    'Déclarations fiscales', 'Rendez-vous client', 'Séance interne', 'Réconciliation bancaire',
    'Décompte TVA', 'Classement et archivage', 'Réponse aux courriels clients',
  ];
  const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  for (let i = 0; i < n; i++) {
    const d = new Date();
    d.setDate(d.getDate() - rand(0, 240));
    await pool.query(
      'INSERT INTO entries (username, date, project, hours, description) VALUES ($1, $2, $3, $4, $5)',
      [user, d.toISOString().slice(0, 10), PROJECTS[rand(0, PROJECTS.length - 1)],
       rand(1, 16) * 0.5, descriptions[rand(0, descriptions.length - 1)]]
    );
  }
  // Même l'outil d'audit doit invalider : il modifie les données.
  await redis.del('totaux:' + user);

  res.json({ injectees: n });
});

// ---------- espace RH (mission D) ----------
// La RH consulte les saisies de TOUT le monde : réservé au rôle « rh ».
app.get('/api/rh/saisies', verifierJeton, exigerRole('rh'), async (req, res) => {
  const { rows } = await pool.query('SELECT * FROM entries ORDER BY username, date DESC');
  res.json(rows);
});

// ---------- récapitulatif hebdomadaire ----------
// Repris tel quel de l'ancien système : la mise en page est complexe,
// la génération prend du temps, c'est comme ça (dixit le stagiaire).
app.get('/api/recap', verifierJeton, async (req, res) => {
  const user = req.utilisateur;

  // génération du document (c'est long mais c'est normal)
  const fin = Date.now() + 4000;
  while (Date.now() < fin) { /* on attend que ça génère */ }

  const { rows } = await pool.query(
    'SELECT * FROM entries WHERE username = $1 ORDER BY date', [user]
  );
  const semaines = {};
  for (const e of rows) {
    const w = weekOf(e.date);
    if (!semaines[w]) semaines[w] = [];
    semaines[w].push(e);
  }

  let contenu = '';
  for (const w of Object.keys(semaines)) {
    let t = 0;
    let lignes = '';
    for (const e of semaines[w]) {
      t += e.hours;
      lignes += `<tr><td>${e.date}</td><td>${e.project}</td><td>${e.hours}</td><td>${e.description}</td></tr>`;
    }
    contenu += `<h2>Semaine ${w} (total : ${t} h)</h2>
<table><tr><th>Date</th><th>Projet</th><th>Heures</th><th>Description</th></tr>${lignes}</table><br>`;
  }

  res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TimeTrack - Récapitulatif</title>
<style>
  body { font-family: Georgia, serif; margin: 30px; }
  table { border-collapse: collapse; width: 100%; }
  td, th { border: 1px solid #888; padding: 4px 8px; font-size: 12px; }
  th { background: #eee; }
</style></head>
<body>
<h1>Récapitulatif hebdomadaire - ${user}</h1>
<p>Chronos &amp; Associés - document à imprimer et signer pour les RH</p>
${contenu}
</body></html>`);
});

// ---------- démarrage ----------

initDb().then(() => {
  app.listen(3000, () => {
    console.log('TimeTrack v2.5 démarré sur http://localhost:3000/app');
  });
});
