// ============================================================
// TimeTrack v2.5 - nouvelle interface (client)
// Nouveautés : connexion/déconnexion via l'API, bouton
// récapitulatif. Ce fichier ne change pas pendant la séance 3 :
// aujourd'hui, on travaille sur l'infrastructure.
// ============================================================

const PROJETS = ['Comptabilité Muller SA', 'Audit Fiduciaire Perret', 'Fiscalité privés', 'Administration interne'];

const selectProjet = document.getElementById('projet');
for (const p of PROJETS) {
  const opt = document.createElement('option');
  opt.textContent = p;
  selectProjet.appendChild(opt);
}

// ---------- session ----------

async function verifierSession() {
  const rep = await fetch('/api/moi');
  if (rep.ok) {
    const { utilisateur } = await rep.json();
    document.getElementById('zone-connexion').style.display = 'none';
    document.getElementById('zone-session').style.display = '';
    document.getElementById('nom-utilisateur').textContent = utilisateur;
    document.getElementById('contenu').style.display = '';
    chargerSaisies();
    chargerTotaux();
  } else {
    document.getElementById('zone-connexion').style.display = '';
    document.getElementById('zone-session').style.display = 'none';
    document.getElementById('contenu').style.display = 'none';
  }
}

async function seConnecter() {
  const username = document.getElementById('login-nom').value;
  const rep = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username }),
  });
  if (rep.ok) verifierSession();
}

async function seDeconnecter() {
  await fetch('/api/logout', { method: 'POST' });
  verifierSession();
}

// ---------- saisies ----------

async function chargerSaisies(semaine) {
  let url = '/api/saisies';
  if (semaine) url += '?semaine=' + encodeURIComponent(semaine);

  const reponse = await fetch(url);
  if (!reponse.ok) {
    afficherErreur(`Le serveur a répondu ${reponse.status}.`);
    return;
  }

  const saisies = await reponse.json();
  const tbody = document.getElementById('liste');
  tbody.innerHTML = '';
  for (const s of saisies) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${s.date}</td><td>${s.project}</td><td>${s.hours}</td><td>${s.description ?? ''}</td><td></td>`;
    const btn = document.createElement('button');
    btn.textContent = 'Supprimer';
    btn.addEventListener('click', async () => {
      const rep = await fetch('/api/saisies/' + s.id, { method: 'DELETE' });
      if (rep.status === 204) {
        chargerSaisies(document.getElementById('filtre').value);
      } else {
        afficherErreur(`Suppression refusée (${rep.status})`);
      }
    });
    tr.lastElementChild.appendChild(btn);
    tbody.appendChild(tr);
  }
}

async function ajouterSaisie() {
  afficherErreur('');

  const nouvelleSaisie = {
    date: document.getElementById('date').value,
    project: document.getElementById('projet').value,
    hours: parseFloat(document.getElementById('heures').value),
    description: document.getElementById('description').value,
  };

  const reponse = await fetch('/api/saisies', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(nouvelleSaisie),
  });

  if (reponse.status === 201) {
    document.getElementById('heures').value = '';
    document.getElementById('description').value = '';
    chargerSaisies();
  } else {
    const corps = await reponse.json().catch(() => ({}));
    afficherErreur(`Refusé par le serveur (${reponse.status}) : ${corps.erreur ?? 'raison inconnue'}`);
  }
}

// ---------- totaux ----------

async function chargerTotaux() {
  const tbody = document.getElementById('totaux');
  const info = document.getElementById('info-totaux');
  tbody.innerHTML = '<tr><td colspan="2">Calcul en cours (vérification d\'intégrité)...</td></tr>';
  info.textContent = '';

  const reponse = await fetch('/api/totaux');
  if (!reponse.ok) return;

  const donnees = await reponse.json();
  // Compatibilité : l'API renvoie { totaux, depuis, ms } depuis la v3.5
  const totaux = donnees.totaux ?? donnees;

  tbody.innerHTML = '';
  for (const projet of Object.keys(totaux)) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${projet}</td><td>${totaux[projet]} h</td>`;
    tbody.appendChild(tr);
  }

  if (donnees.depuis) {
    const secondes = (donnees.ms / 1000).toFixed(donnees.ms >= 1000 ? 1 : 3);
    info.textContent = donnees.depuis === 'cache'
      ? `Depuis le cache, en ${donnees.ms} ms`
      : `Calculé (vérification d'intégrité comprise) en ${secondes} s`;
    info.style.color = donnees.depuis === 'cache' ? '#2a7a2a' : '#a35b00';
  }
}

// ---------- outils d'audit ----------

async function injecterSaisies() {
  const btn = document.getElementById('btn-seed');
  btn.disabled = true;
  btn.textContent = 'Injection en cours...';
  const rep = await fetch('/api/demo/seed?n=200', { method: 'POST' });
  btn.disabled = false;
  btn.textContent = 'Injecter 200 saisies';
  if (rep.ok) {
    chargerSaisies();
  } else {
    afficherErreur(`Injection refusée (${rep.status})`);
  }
}

// ---------- branchements ----------

function afficherErreur(message) {
  document.getElementById('erreur').textContent = message;
}

document.getElementById('btn-connexion').addEventListener('click', seConnecter);
document.getElementById('btn-deconnexion').addEventListener('click', seDeconnecter);
document.getElementById('btn-ajouter').addEventListener('click', ajouterSaisie);
document.getElementById('btn-totaux').addEventListener('click', chargerTotaux);
document.getElementById('btn-seed').addEventListener('click', injecterSaisies);
document.getElementById('btn-recap').addEventListener('click', () => window.open('/api/recap', '_blank'));
document.getElementById('btn-filtrer').addEventListener('click', () => chargerSaisies(document.getElementById('filtre').value));
document.getElementById('btn-tout').addEventListener('click', () => {
  document.getElementById('filtre').value = '';
  chargerSaisies();
});

verifierSession();
