# Exploration : Redis à nu (20 minutes, seul, avant la mission A)

Avant de brancher Redis sur TimeTrack, faites-en le tour à mains
nues. La règle du jeu : pour CHAQUE manipulation, répondez à la
question de tête AVANT d'exécuter. Un pari faux vaut autant qu'un
pari juste : il signale une découverte.

## Mise en place (deux révisions de la semaine passée, au passage)

```
docker run --name lab-redis -d redis:7-alpine
docker exec -it lab-redis redis-cli
```

Vous êtes dans le client Redis (l'invite affiche 127.0.0.1:6379).

## Les cinq manipulations

**1.** Que va répondre le GET ?
```
SET totaux:jvermot "42h"
GET totaux:jvermot
```

**2.** Cette clé n'a JAMAIS été écrite. Que va-t-il se passer ?
```
GET totaux:cdubois
```

**3.** La clé existe déjà. Le SET va-t-il refuser, avertir, écraser ?
```
SET totaux:jvermot "45h"
GET totaux:jvermot
```

**4.** Que vaudra le GET après l'attente ?
```
EXPIRE totaux:jvermot 10
TTL totaux:jvermot
(attendez 10 secondes...)
GET totaux:jvermot
```

**5.** Redis va être redémarré. La clé survivra-t-elle ?
```
SET totaux:jvermot "42h"
exit
docker stop lab-redis
docker start lab-redis
docker exec -it lab-redis redis-cli
GET totaux:jvermot
```

## Les trois questions de synthèse (répondez par écrit, 3 lignes)

A. Manipulation 2 : que devra faire NOTRE CODE quand Redis répond
   ça ? (Indice : c'est la moitié de la mission B.)

B. Manipulation 4 : à quoi cette « péremption » pourrait-elle servir
   dans un cache ? Et quel serait son danger ?

C. Manipulation 5 : d'après ce que vous avez observé, le service
   cache de la mission A aura-t-il besoin d'un volume, comme la
   base ? Pourquoi ?

## Nettoyage

```
exit
docker rm -f lab-redis
```
