// ============================================================
// TimeTrack v3.5 - intervention n°4 : le correctif des totaux
//
// La direction MAINTIENT la double vérification d'intégrité
// (réglementaire, paraît-il). Votre mission : faire en sorte de
// ne plus la subir à chaque affichage. L'outil : Redis, un
// composant de système de la catégorie « conservation des
// données », spécialisé clé-valeur en mémoire.
// Voir README.md pour les missions.
// ============================================================

const express = require('express');
const { Pool } = require('pg');
const Redis = require('ioredis');

const app = express();
app.use(express.json());
app.use('/app', express.static('public'));

// Le Pool lit sa configuration dans les variables d'environnement :
// PGHOST, PGUSER, PGPASSWORD, PGDATABASE (et PGPORT, 5432 par défaut).
const pool = new Pool();

// Connexion à Redis. Même principe : le nom d'hôte vient de
// l'environnement (et entre conteneurs, localhost n'existe pas...).
const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  lazyConnect: false,
});
redis.on('error', (err) => console.log('Redis :', err.message));

const PROJECTS = ['Comptabilité Muller SA', 'Audit Fiduciaire Perret', 'Fiscalité privés', 'Administration interne'];

// ---------- initialisation de la base ----------

async function initDb() {
  // La base peut mettre quelques secondes à démarrer (surtout dans un
  // conteneur fraîchement créé) : on réessaie plutôt que de planter.
  // Première graine de « design for failure », on en reparlera...
  for (let essai = 1; essai <= 10; essai++) {
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS entries (
          id SERIAL PRIMARY KEY,
          username TEXT NOT NULL,
          date TEXT NOT NULL,
          project TEXT NOT NULL,
          hours REAL NOT NULL,
          description TEXT
        )
      `);
      console.log('Base de données prête.');
      await seedSiVide();
      return;
    } catch (err) {
      console.log(`Base pas encore joignable (essai ${essai}/10) : ${err.message}`);
      await new Promise(r => setTimeout(r, 2000));
    }
  }
  console.error('Impossible de joindre la base de données. Le serveur s\'arrête.');
  process.exit(1);
}

async function seedSiVide() {
  const { rows } = await pool.query('SELECT COUNT(*)::int AS n FROM entries');
  if (rows[0].n > 0) return;

  const demo = [
    ['jvermot', '2019-08-12', 'Comptabilité Muller SA', 3.5, 'Saisie des pièces comptables T2'],
    ['jvermot', '2019-08-12', 'Administration interne', 1, 'Séance équipe du lundi'],
    ['jvermot', '2019-08-13', 'Comptabilité Muller SA', 4, 'Bouclement intermédiaire'],
    ['jvermot', '2019-08-14', 'Fiscalité privés', 2.5, 'Déclarations en retard (encore)'],
    ['cdubois', '2019-08-12', 'Audit Fiduciaire Perret', 6, 'Contrôle des écritures 2018'],
    ['cdubois', '2019-08-13', 'Audit Fiduciaire Perret', 5.5, 'Suite du contrôle + rapport'],
    ['cdubois', '2019-08-14', 'Administration interne', 2, 'Rangement archives sous-sol'],
    ['cdubois', '2019-08-15', 'Fiscalité privés', 3, 'RDV client Mme Jeanneret'],
    ['mfavre', '2019-08-12', 'Fiscalité privés', 4, 'Déclarations frontaliers'],
    ['mfavre', '2019-08-13', 'Comptabilité Muller SA', 2, 'Coup de main à Julie'],
    ['mfavre', '2019-08-14', 'Fiscalité privés', 5, 'Déclarations frontaliers (suite)'],
    ['mfavre', '2019-08-15', 'Administration interne', 1.5, 'Mise à jour du site web'],
  ];
  for (const d of demo) {
    await pool.query(
      'INSERT INTO entries (username, date, project, hours, description) VALUES ($1, $2, $3, $4, $5)', d
    );
  }
  console.log('Données de démonstration injectées.');
}

// ---------- fonctions utiles (héritées, à moderniser un jour) ----------

// Toujours le cookie en clair du stagiaire. La direction a demandé
// « quelque chose de plus sérieux », c'est prévu dans une intervention
// ultérieure du mandat.
function getUser(req) {
  const cookie = req.headers.cookie || '';
  for (const part of cookie.split(';')) {
    const p = part.trim();
    if (p.startsWith('user=')) return decodeURIComponent(p.substring(5));
  }
  return null;
}

// Toujours la formule « trouvée sur un forum » du stagiaire.
function weekOf(dateStr) {
  const d = new Date(dateStr);
  const jan1 = new Date(d.getFullYear(), 0, 1);
  return Math.ceil((((d - jan1) / 86400000) + jan1.getDay() + 1) / 7);
}

// ---------- authentification (provisoire !) ----------

app.post('/api/login', (req, res) => {
  const { username } = req.body;
  if (!username || !username.trim()) {
    return res.status(400).json({ erreur: 'Nom d\'utilisateur requis' });
  }
  res.setHeader('Set-Cookie', 'user=' + encodeURIComponent(username.trim()) + '; Path=/');
  res.json({ utilisateur: username.trim() });
});

app.post('/api/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'user=; Path=/; Max-Age=0');
  res.status(204).end();
});

app.get('/api/moi', (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });
  res.json({ utilisateur: user });
});

// ---------- API saisies ----------

app.get('/api/saisies', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const { rows } = await pool.query(
    'SELECT * FROM entries WHERE username = $1 ORDER BY date DESC', [user]
  );

  let saisies = rows;
  if (req.query.semaine) {
    saisies = saisies.filter(e => weekOf(e.date) == req.query.semaine);
  }
  res.json(saisies);
});

app.post('/api/saisies', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const { date, project, hours, description } = req.body;

  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return res.status(400).json({ erreur: 'Date manquante ou invalide (format attendu AAAA-MM-JJ)' });
  }
  if (!PROJECTS.includes(project)) {
    return res.status(400).json({ erreur: 'Projet inconnu' });
  }
  const h = Number(hours);
  if (!Number.isFinite(h) || h < 0.5 || h > 24) {
    return res.status(400).json({ erreur: 'Heures invalides (entre 0.5 et 24)' });
  }

  const { rows } = await pool.query(
    'INSERT INTO entries (username, date, project, hours, description) VALUES ($1, $2, $3, $4, $5) RETURNING *',
    [user, date, project, h, description || '']
  );
  res.status(201).json(rows[0]);
});

app.delete('/api/saisies/:id', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const resultat = await pool.query(
    'DELETE FROM entries WHERE id = $1 AND username = $2', [req.params.id, user]
  );
  if (resultat.rowCount === 0) {
    return res.status(404).json({ erreur: 'Saisie introuvable' });
  }
  res.status(204).end();
});

// ---------- totaux ----------
// La « double vérification d'intégrité » reste (réglementaire).
// Mais rien n'oblige à la refaire si RIEN n'a changé depuis le
// dernier calcul... c'est tout l'objet des missions B et C.
app.get('/api/totaux', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const depart = Date.now();
  const cle = 'totaux:' + user;

  // --- MISSION B (1/2) : consulter le frigo avant le magasin ---
  // Lire la clé dans Redis. Si elle existe, renvoyer son contenu
  // IMMÉDIATEMENT (sans passer par le calcul), avec depuis: 'cache'
  // et le temps écoulé en ms, sur le modèle du res.json() tout en
  // bas de la route. Attention : Redis stocke des CHAÎNES, et
  // l'exploration vous a montré ce qu'il répond quand la clé
  // n'existe pas. Vos outils : la fiche mémo et l'exploration.
  // TODO Mission B (1/2)

  // --- le calcul complet (avec la vérification réglementaire) ---
  const totaux = {};
  for (const p of PROJECTS) {
    const { rows } = await pool.query('SELECT * FROM entries WHERE username = $1', [user]);
    let t = 0;
    for (const e of rows) {
      const check = Date.now() + 60;
      while (Date.now() < check) { /* vérification en cours */ }
      if (e.project === p) t += e.hours;
    }
    totaux[p] = t;
  }

  // --- MISSION B (2/2) : remplir le frigo pour la prochaine fois ---
  // Stocker le résultat du calcul dans Redis, sous la même clé,
  // pour que le prochain passage le trouve. Même contrainte qu'au
  // 1/2 : Redis ne stocke que des chaînes.
  // TODO Mission B (2/2)

  res.json({ totaux, depuis: 'calcul', ms: Date.now() - depart });
});

// --- MISSION C : le cache qui ment ---
// Faites le test AVANT de coder : chargez les totaux (mission B
// active), ajoutez une saisie, rechargez les totaux. Alors ?
// Un cache doit être INVALIDÉ quand la donnée source change.
// À vous de trouver : QUELLE commande Redis supprime une clé
// (l'exploration et la fiche mémo la contiennent), quelle CLÉ
// exactement, et surtout À QUELS ENDROITS du code la placer
// (indice : là où les données CHANGENT, et il y a deux endroits).
// Question de synthèse : pourquoi invalider PAR utilisateur,
// et pas vider tout Redis ?

// ---------- outil d'audit (à retirer en production, évidemment) ----------
// Injecte n saisies aléatoires pour l'utilisateur connecté, afin de
// simuler plusieurs mois d'utilisation réelle. Fourni par la société
// d'audit dans le cadre du mandat.
app.post('/api/demo/seed', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const n = Math.min(parseInt(req.query.n || '200', 10), 1000);
  const descriptions = [
    'Saisie des pièces comptables', 'Contrôle des écritures', 'Préparation du bouclement',
    'Déclarations fiscales', 'Rendez-vous client', 'Séance interne', 'Réconciliation bancaire',
    'Décompte TVA', 'Classement et archivage', 'Réponse aux courriels clients',
  ];
  const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  for (let i = 0; i < n; i++) {
    const d = new Date();
    d.setDate(d.getDate() - rand(0, 240));
    await pool.query(
      'INSERT INTO entries (username, date, project, hours, description) VALUES ($1, $2, $3, $4, $5)',
      [user, d.toISOString().slice(0, 10), PROJECTS[rand(0, PROJECTS.length - 1)],
       rand(1, 16) * 0.5, descriptions[rand(0, descriptions.length - 1)]]
    );
  }
  res.json({ injectees: n });
});

// ---------- récapitulatif hebdomadaire ----------
// Repris tel quel de l'ancien système : la mise en page est complexe,
// la génération prend du temps, c'est comme ça (dixit le stagiaire).
app.get('/api/recap', async (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).send('Non authentifié');

  // génération du document (c'est long mais c'est normal)
  const fin = Date.now() + 4000;
  while (Date.now() < fin) { /* on attend que ça génère */ }

  const { rows } = await pool.query(
    'SELECT * FROM entries WHERE username = $1 ORDER BY date', [user]
  );
  const semaines = {};
  for (const e of rows) {
    const w = weekOf(e.date);
    if (!semaines[w]) semaines[w] = [];
    semaines[w].push(e);
  }

  let contenu = '';
  for (const w of Object.keys(semaines)) {
    let t = 0;
    let lignes = '';
    for (const e of semaines[w]) {
      t += e.hours;
      lignes += `<tr><td>${e.date}</td><td>${e.project}</td><td>${e.hours}</td><td>${e.description}</td></tr>`;
    }
    contenu += `<h2>Semaine ${w} (total : ${t} h)</h2>
<table><tr><th>Date</th><th>Projet</th><th>Heures</th><th>Description</th></tr>${lignes}</table><br>`;
  }

  res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TimeTrack - Récapitulatif</title>
<style>
  body { font-family: Georgia, serif; margin: 30px; }
  table { border-collapse: collapse; width: 100%; }
  td, th { border: 1px solid #888; padding: 4px 8px; font-size: 12px; }
  th { background: #eee; }
</style></head>
<body>
<h1>Récapitulatif hebdomadaire - ${user}</h1>
<p>Chronos &amp; Associés - document à imprimer et signer pour les RH</p>
${contenu}
</body></html>`);
});

// ---------- démarrage ----------

initDb().then(() => {
  app.listen(3000, () => {
    console.log('TimeTrack v2.5 démarré sur http://localhost:3000/app');
  });
});
