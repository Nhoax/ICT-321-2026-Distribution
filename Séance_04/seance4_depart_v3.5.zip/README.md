# TimeTrack v3.5 - intervention n°4 : le correctif des totaux

Verdict de la direction : la double vérification d'intégrité est
réglementaire, elle RESTE. Mais les employés ne doivent plus la subir
à chaque affichage. La solution : ne calculer que quand c'est
nécessaire, et mémoriser le résultat. Entrée en scène de Redis.

## Mission 0 : l'exploration

Déroulez EXPLORATION_REDIS.md (20 minutes, seul) : cinq
manipulations pour apprivoiser Redis à mains nues, et trois
questions de synthèse qui préparent directement les missions.

## Mission A : le service Redis

Complétez `compose.yaml` (TODO) pour ajouter le service `cache`
(image redis:7-alpine) et câbler la variable REDIS_HOST de l'API.
Puis `docker compose up --build`. Vérifiez dans les logs que l'API
ne râle pas contre Redis.

## Mission B : le cache des totaux

Dans `server.js`, route GET /api/totaux, deux TODO vous attendent :

1. AVANT le calcul : consulter Redis. Si la clé existe, renvoyer
   son contenu directement (le frigo avant le magasin).
2. APRÈS le calcul : stocker le résultat dans Redis.

Test : chargez les totaux deux fois de suite. L'interface affiche
la provenance (calcul ou cache) et le temps. Convaincant ?

## Mission C : le cache qui ment

Faites d'abord le test : totaux chargés (donc en cache), ajoutez une
saisie, rechargez les totaux. Que voyez-vous ? Que voit l'employé ?
Que dira le service RH ?

Corrigez en invalidant le cache là où les données changent
(POST et DELETE des saisies). Une seule ligne à chaque endroit,
mais LA bonne ligne au BON endroit.

## Le test final

Bouton « Injecter 200 saisies » (outils d'audit, dans l'interface) :

1. Injectez 200 saisies.
2. Chargez les totaux : long (c'est le calcul, vérification comprise).
3. Rechargez : instantané.
4. Ajoutez une saisie, rechargez : recalcul (long), puis instantané.

Si vous observez exactement cette séquence, le grief « page Totaux
inutilisable » peut être officiellement coché.

## Bonus pour les rapides

- TTL : `redis.set(cle, valeur, 'EX', 3600)` fait expirer la clé
  après une heure. Utile ? Dangereux ? Les deux ? Argumentez.
- Explorez le contenu de Redis pendant que ça tourne :
  `docker compose exec cache redis-cli`, puis `KEYS *` et
  `GET totaux:votre_nom`.

## Règle d'or : après TOUTE modification du code

```
docker compose up -d --build
```

Sans --build, le conteneur continue de servir l'ANCIENNE version du
code, copiée dans l'image au moment du dernier build (COPY . .).
Symptôme classique : « ma modification n'a aucun effet ». Pensez
aussi au Ctrl+F5 côté navigateur pour les fichiers du client.
