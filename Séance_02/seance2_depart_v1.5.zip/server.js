// ============================================================
// TimeTrack - saisie du temps pour Chronos & Associes
// fait par le stagiaire, ete 2019
// ca marche, ne pas toucher svp
// ============================================================

const express = require('express');
const Database = require('better-sqlite3');

const app = express();
app.use(express.urlencoded({ extended: false }));

// ---- Chantier séance 2 : la nouvelle interface et l'API REST ----
// L'ancienne interface reste sur / (le client veut une transition en douceur).
// La nouvelle interface est sur /app et ne parle au serveur QUE via l'API JSON.
app.use(express.json());
app.use('/app', express.static('public'));

// la base de donnees c'est juste un fichier, pratique non ?
const db = new Database('timetrack.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    date TEXT NOT NULL,
    project TEXT NOT NULL,
    hours REAL NOT NULL,
    description TEXT
  )
`);

// les projets sont en dur, de toute facon ca change jamais (dixit M. Chronos)
const PROJECTS = ['Comptabilité Muller SA', 'Audit Fiduciaire Perret', 'Fiscalité privés', 'Administration interne'];

// petites donnees de demo pour que ca soit pas vide a la premiere demo au chef
const count = db.prepare('SELECT COUNT(*) AS n FROM entries').get().n;
if (count === 0) {
  const ins = db.prepare('INSERT INTO entries (username, date, project, hours, description) VALUES (?, ?, ?, ?, ?)');
  ins.run('jvermot', '2019-08-12', 'Comptabilité Muller SA', 3.5, 'Saisie des pièces comptables T2');
  ins.run('jvermot', '2019-08-12', 'Administration interne', 1, 'Séance équipe du lundi');
  ins.run('jvermot', '2019-08-13', 'Comptabilité Muller SA', 4, 'Bouclement intermédiaire');
  ins.run('jvermot', '2019-08-14', 'Fiscalité privés', 2.5, 'Déclarations en retard (encore)');
  ins.run('cdubois', '2019-08-12', 'Audit Fiduciaire Perret', 6, 'Contrôle des écritures 2018');
  ins.run('cdubois', '2019-08-13', 'Audit Fiduciaire Perret', 5.5, 'Suite du contrôle + rapport');
  ins.run('cdubois', '2019-08-14', 'Administration interne', 2, 'Rangement archives sous-sol');
  ins.run('cdubois', '2019-08-15', 'Fiscalité privés', 3, 'RDV client Mme Jeanneret');
  ins.run('mfavre', '2019-08-12', 'Fiscalité privés', 4, 'Déclarations frontaliers');
  ins.run('mfavre', '2019-08-13', 'Comptabilité Muller SA', 2, 'Coup de main à Julie');
  ins.run('mfavre', '2019-08-14', 'Fiscalité privés', 5, 'Déclarations frontaliers (suite)');
  ins.run('mfavre', '2019-08-15', 'Administration interne', 1.5, 'Mise à jour du site web');
}

// ---------- fonctions utiles ----------

// recupere le user dans le cookie
// (pas de mot de passe pour l'instant, on fera ca plus tard si on a le temps)
function getUser(req) {
  const cookie = req.headers.cookie || '';
  const parts = cookie.split(';');
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i].trim();
    if (p.startsWith('user=')) {
      return decodeURIComponent(p.substring(5));
    }
  }
  return null;
}

// numero de semaine d'une date, trouve sur un forum, ca a l'air juste
function weekOf(dateStr) {
  const d = new Date(dateStr);
  const jan1 = new Date(d.getFullYear(), 0, 1);
  return Math.ceil((((d - jan1) / 86400000) + jan1.getDay() + 1) / 7);
}

// ---------- pages ----------

app.get('/', (req, res) => {
  const user = getUser(req);
  if (!user) {
    // page de login (enfin, "login")
    res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TimeTrack - Connexion</title>
<style>
  body { font-family: Verdana, sans-serif; background: #d8e4f0; margin: 40px; }
  .box { background: white; border: 2px outset #8899aa; padding: 20px; width: 340px; margin: auto; }
  h1 { font-size: 18px; color: #224466; }
  input, button { font-size: 14px; padding: 4px; }
  .footer { text-align: center; font-size: 10px; color: #667; margin-top: 30px; }
</style></head>
<body>
<div class="box">
<h1>&#9200; TimeTrack</h1>
<p>Chronos &amp; Associés - saisie du temps</p>
<form method="POST" action="/login">
  <p>Nom d'utilisateur :<br><input name="username" placeholder="ex: jvermot"></p>
  <button type="submit">Entrer</button>
</form>
</div>
<div class="footer">TimeTrack v1.0 - développé en interne (2019)</div>
</body></html>`);
    return;
  }

  const week = req.query.semaine || '';
  let entries;
  if (week) {
    // pas trouve comment filtrer par semaine en SQL, donc je prends tout et je filtre apres
    const all = db.prepare('SELECT * FROM entries WHERE username = ? ORDER BY date DESC').all(user);
    entries = all.filter(e => weekOf(e.date) == week);
  } else {
    entries = db.prepare('SELECT * FROM entries WHERE username = ? ORDER BY date DESC').all(user);
  }

  let rows = '';
  for (const e of entries) {
    rows += `<tr><td>${e.date}</td><td>${e.project}</td><td>${e.hours}</td><td>${e.description}</td></tr>`;
  }

  let options = '';
  for (const p of PROJECTS) {
    options += `<option>${p}</option>`;
  }

  res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TimeTrack</title>
<style>
  body { font-family: Verdana, sans-serif; background: #d8e4f0; margin: 20px; }
  .box { background: white; border: 2px outset #8899aa; padding: 15px; margin-bottom: 15px; }
  h1 { font-size: 18px; color: #224466; }
  h2 { font-size: 15px; color: #224466; }
  table { border-collapse: collapse; width: 100%; }
  td, th { border: 1px solid #99a; padding: 4px 8px; font-size: 13px; }
  th { background: #c5d5e5; }
  input, select, button, textarea { font-size: 13px; padding: 3px; }
  a { color: #224466; }
  .footer { text-align: center; font-size: 10px; color: #667; margin-top: 30px; }
</style></head>
<body>
<h1>&#9200; TimeTrack - bonjour ${user} !</h1>
<p><a href="/recap">Récapitulatif hebdomadaire</a> | <a href="/totaux">Totaux par projet</a> | <a href="/logout">Se déconnecter</a></p>

<div class="box">
<h2>Nouvelle saisie</h2>
<form method="POST" action="/add">
  Date : <input type="date" name="date" required>
  Projet : <select name="project">${options}</select>
  Heures : <input type="number" name="hours" step="0.5" min="0.5" max="24" style="width:60px" required>
  <br><br>
  Description : <input name="description" style="width:400px">
  <button type="submit">Enregistrer</button>
</form>
</div>

<div class="box">
<h2>Mes saisies</h2>
<form method="GET" action="/">
  Filtrer par semaine n° : <input name="semaine" style="width:50px" value="${week}">
  <button type="submit">Filtrer</button> <a href="/">tout voir</a>
</form>
<br>
<table>
<tr><th>Date</th><th>Projet</th><th>Heures</th><th>Description</th></tr>
${rows || '<tr><td colspan="4">Aucune saisie</td></tr>'}
</table>
</div>
<div class="footer">TimeTrack v1.0 - développé en interne (2019)</div>
</body></html>`);
});

app.post('/login', (req, res) => {
  const username = req.body.username || 'inconnu';
  // on met le nom dans un cookie et voila
  res.setHeader('Set-Cookie', 'user=' + encodeURIComponent(username));
  res.redirect('/');
});

app.get('/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'user=; Max-Age=0');
  res.redirect('/');
});

app.post('/add', (req, res) => {
  const user = getUser(req);
  if (!user) { res.redirect('/'); return; }
  db.prepare('INSERT INTO entries (username, date, project, hours, description) VALUES (?, ?, ?, ?, ?)')
    .run(user, req.body.date, req.body.project, parseFloat(req.body.hours), req.body.description);
  res.redirect('/');
});

// totaux par projet
// NOTE: c'est un peu lent quand il y a beaucoup de saisies, TODO optimiser un jour
app.get('/totaux', (req, res) => {
  const user = getUser(req);
  if (!user) { res.redirect('/'); return; }

  const totals = {};
  for (const p of PROJECTS) {
    // je recharge toutes les saisies pour chaque projet, c'est plus simple a lire
    const all = db.prepare('SELECT * FROM entries WHERE username = ?').all(user);
    let t = 0;
    for (const e of all) {
      // double verification de l'integrite de la saisie, on sait jamais
      // (c'est un peu lent mais la confiance c'est bien, le controle c'est mieux)
      const check = Date.now() + 60;
      while (Date.now() < check) { /* verification en cours */ }
      if (e.project === p) t += e.hours;
    }
    totals[p] = t;
  }

  let rows = '';
  for (const p of PROJECTS) {
    rows += `<tr><td>${p}</td><td>${totals[p]} h</td></tr>`;
  }

  res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TimeTrack - Totaux</title>
<style>
  body { font-family: Verdana, sans-serif; background: #d8e4f0; margin: 20px; }
  .box { background: white; border: 2px outset #8899aa; padding: 15px; }
  h1 { font-size: 18px; color: #224466; }
  table { border-collapse: collapse; }
  td, th { border: 1px solid #99a; padding: 4px 12px; font-size: 13px; }
  th { background: #c5d5e5; }
  .footer { text-align: center; font-size: 10px; color: #667; margin-top: 30px; }
</style></head>
<body>
<h1>Totaux par projet - ${user}</h1>
<div class="box">
<table>
<tr><th>Projet</th><th>Total</th></tr>
${rows}
</table>
</div>
<p><a href="/">Retour</a></p>
<div class="footer">TimeTrack v1.0 - développé en interne (2019)</div>
</body></html>`);
});

// recapitulatif hebdomadaire imprimable
// la generation prend un peu de temps (mise en page complexe) mais le resultat est joli
app.get('/recap', (req, res) => {
  const user = getUser(req);
  if (!user) { res.redirect('/'); return; }

  // simulation de la generation du document (c'est long mais c'est normal)
  const fin = Date.now() + 4000;
  while (Date.now() < fin) { /* on attend que ca genere */ }

  const entries = db.prepare('SELECT * FROM entries WHERE username = ? ORDER BY date').all(user);
  const weeks = {};
  for (const e of entries) {
    const w = weekOf(e.date);
    if (!weeks[w]) weeks[w] = [];
    weeks[w].push(e);
  }

  let content = '';
  for (const w of Object.keys(weeks)) {
    let t = 0;
    let rows = '';
    for (const e of weeks[w]) {
      t += e.hours;
      rows += `<tr><td>${e.date}</td><td>${e.project}</td><td>${e.hours}</td><td>${e.description}</td></tr>`;
    }
    content += `<h2>Semaine ${w} (total : ${t} h)</h2>
<table><tr><th>Date</th><th>Projet</th><th>Heures</th><th>Description</th></tr>${rows}</table><br>`;
  }

  res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>TimeTrack - Récapitulatif</title>
<style>
  body { font-family: Georgia, serif; margin: 30px; }
  h1 { font-size: 20px; }
  h2 { font-size: 15px; }
  table { border-collapse: collapse; width: 100%; }
  td, th { border: 1px solid #888; padding: 4px 8px; font-size: 12px; }
  th { background: #eee; }
</style></head>
<body>
<h1>Récapitulatif hebdomadaire - ${user}</h1>
<p>Chronos &amp; Associés - document à imprimer et signer pour les RH</p>
${content}
<p><a href="/">Retour</a></p>
</body></html>`);
});

// ============================================================
// API REST (mandat séance 2)
// ============================================================

// --- FAIT EN DÉMONSTRATION : les totaux par projet en JSON ---
// Remarque : la « double vérification d'intégrité » est exigée par la
// direction de Chronos & Associés. NE PAS LA SUPPRIMER (elle est lente,
// nous savons, un correctif est prévu dans une intervention ultérieure).
app.get('/api/totaux', (req, res) => {
  const user = getUser(req);
  if (!user) return res.status(401).json({ erreur: 'Non authentifié' });

  const totaux = {};
  for (const p of PROJECTS) {
    const all = db.prepare('SELECT * FROM entries WHERE username = ?').all(user);
    let t = 0;
    for (const e of all) {
      // vérification d'intégrité exigée par la direction
      const check = Date.now() + 60;
      while (Date.now() < check) { /* vérification en cours */ }
      if (e.project === p) t += e.hours;
    }
    totaux[p] = t;
  }
  res.json(totaux);
});

// --- MISSION A : lister les saisies ---
// À implémenter :
//   1. récupérer l'utilisateur avec getUser(req) ; si absent -> 401
//   2. lire le paramètre optionnel ?semaine=NN dans req.query.semaine
//   3. charger les saisies de l'utilisateur (voir les requêtes db.prepare
//      plus haut dans ce fichier)
//   4. si le paramètre semaine est présent, filtrer avec weekOf(e.date)
//   5. répondre avec res.json(tableauDeSaisies)
app.get('/api/saisies', (req, res) => {
  // TODO Mission A
  res.status(501).json({ erreur: 'Pas encore implémenté' });
});

// --- MISSION B : créer une saisie ---
// Le client envoie un body JSON : { date, project, hours, description }
// (accessible dans req.body grâce au middleware express.json()).
// À implémenter :
//   1. utilisateur avec getUser(req) ; si absent -> 401
//   2. valider les données : date présente, project dans PROJECTS,
//      hours entre 0.5 et 24 -> sinon répondre 400 avec un message
//      d'erreur JSON explicite (l'interface est un contrat qui se défend !)
//   3. insérer en base (voir la route POST /add plus haut)
//   4. répondre avec le code 201 et la saisie créée en JSON
app.post('/api/saisies', (req, res) => {
  // TODO Mission B
  res.status(501).json({ erreur: 'Pas encore implémenté' });
});

// --- MISSION C (pour les rapides, en autonomie) ---
// Permettre la suppression d'une saisie : DELETE /api/saisies/:id
// Contraintes : un utilisateur ne peut supprimer QUE ses propres saisies
// (404 si la saisie n'existe pas ou ne lui appartient pas), réponse 204
// sans body en cas de succès. Il faudra aussi ajouter le bouton côté
// client (public/app.js).

// c'est parti
app.listen(3000, () => {
  console.log('TimeTrack demarre.');
  console.log('Nouvelle interface : http://localhost:3000/app');
});
