// ============================================================
// TimeTrack - nouvelle interface (client)
// Ce fichier est FOURNI COMPLET pour les missions A et B :
// les appels fetch sont déjà écrits, c'est le serveur qui vous attend.
// Pour la mission C (suppression), c'est à vous des deux côtés.
// ============================================================

const PROJETS = ['Comptabilité Muller SA', 'Audit Fiduciaire Perret', 'Fiscalité privés', 'Administration interne'];

// Remplit la liste déroulante des projets
const selectProjet = document.getElementById('projet');
for (const p of PROJETS) {
  const opt = document.createElement('option');
  opt.textContent = p;
  selectProjet.appendChild(opt);
}

// ---------- Mission A : lister les saisies ----------
async function chargerSaisies(semaine) {
  let url = '/api/saisies';
  if (semaine) {
    url += '?semaine=' + encodeURIComponent(semaine);
  }

  const reponse = await fetch(url);
  if (!reponse.ok) {
    afficherErreur(`Le serveur a répondu ${reponse.status}. Mission A pas encore terminée ?`);
    return;
  }

  const saisies = await reponse.json();
  const tbody = document.getElementById('liste');
  tbody.innerHTML = '';
  for (const s of saisies) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${s.date}</td><td>${s.project}</td><td>${s.hours}</td><td>${s.description ?? ''}</td><td></td>`;
    // Mission C : c'est dans la dernière cellule (vide pour l'instant)
    // qu'un bouton Supprimer devra apparaître.
    tbody.appendChild(tr);
  }
}

// ---------- Mission B : créer une saisie ----------
async function ajouterSaisie() {
  afficherErreur('');

  const nouvelleSaisie = {
    date: document.getElementById('date').value,
    project: document.getElementById('projet').value,
    hours: parseFloat(document.getElementById('heures').value),
    description: document.getElementById('description').value,
  };

  const reponse = await fetch('/api/saisies', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(nouvelleSaisie),
  });

  if (reponse.status === 201) {
    document.getElementById('heures').value = '';
    document.getElementById('description').value = '';
    chargerSaisies(); // on recharge la liste
  } else {
    const corps = await reponse.json().catch(() => ({}));
    afficherErreur(`Refusé par le serveur (${reponse.status}) : ${corps.erreur ?? 'raison inconnue'}`);
  }
}

// ---------- Démonstration : les totaux ----------
async function chargerTotaux() {
  const tbody = document.getElementById('totaux');
  tbody.innerHTML = '<tr><td colspan="2">Calcul en cours (vérification d\'intégrité)...</td></tr>';

  const reponse = await fetch('/api/totaux');
  if (!reponse.ok) return;

  const totaux = await reponse.json();
  tbody.innerHTML = '';
  for (const projet of Object.keys(totaux)) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${projet}</td><td>${totaux[projet]} h</td>`;
    tbody.appendChild(tr);
  }
}

// ---------- Branchements ----------
function afficherErreur(message) {
  document.getElementById('erreur').textContent = message;
}

document.getElementById('btn-ajouter').addEventListener('click', ajouterSaisie);
document.getElementById('btn-totaux').addEventListener('click', chargerTotaux);
document.getElementById('btn-filtrer').addEventListener('click', () => chargerSaisies(document.getElementById('filtre').value));
document.getElementById('btn-tout').addEventListener('click', () => {
  document.getElementById('filtre').value = '';
  chargerSaisies();
});

// Au chargement de la page
chargerSaisies();
chargerTotaux();
