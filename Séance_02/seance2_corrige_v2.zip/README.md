# TimeTrack v2 - CORRIGÉ de la séance 2

Point de départ de l'atelier : l'API REST est en construction.

## Lancement

```
npm install
node server.js
```

- Ancienne interface (celle du stagiaire) : http://localhost:3000
- Nouvelle interface (le chantier) : http://localhost:3000/app

Important : connectez-vous d'abord via l'ancienne interface. Le cookie
de session (si on peut l'appeler ainsi...) est partagé par les deux.

## Vos missions (voir les commentaires dans server.js)

- Mission A : implémenter `GET /api/saisies` (avec filtre `?semaine=NN`)
- Mission B : implémenter `POST /api/saisies` (avec validation, code 201)
- Mission C (autonomie) : `DELETE /api/saisies/:id` côté serveur ET client

Le client (public/app.js) est fourni complet pour A et B : les fetch
sont écrits, ils attendent vos endpoints. Tant qu'un endpoint n'est pas
implémenté, il répond 501 et la nouvelle interface affiche une erreur.

Déjà fait en démonstration : `GET /api/totaux`.
