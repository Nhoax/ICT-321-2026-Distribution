# Démo séance 5 : JWT en pratique

Mini-serveur indépendant pour la démonstration au projecteur.

```
npm install
node server.js
```

Décodeur visuel : http://localhost:3000/decodeur.html

## Scénario de démonstration (les curl dans l'ordre)

```bash
# 1. Le public, sans carte : ça passe
curl http://localhost:3000/api/public

# 2. Le protégé, sans carte : 401
curl -i http://localhost:3000/api/protege

# 3. Login raté : 401
curl -i -X POST -H "Content-Type: application/json" \
  -d '{"username":"jvermot","motDePasse":"faux"}' \
  http://localhost:3000/api/login

# 4. Login réussi : voilà la carte (copiez le token !)
curl -X POST -H "Content-Type: application/json" \
  -d '{"username":"jvermot","motDePasse":"compta123"}' \
  http://localhost:3000/api/login

# 5. Le protégé, avec la carte : 200
curl -H "Authorization: Bearer LE_TOKEN_ICI" \
  http://localhost:3000/api/protege

# 6. Coller le token dans decodeur.html : tout est lisible !

# 7. Falsification : changez UNE lettre du token -> 401
curl -i -H "Authorization: Bearer LE_TOKEN_MODIFIE" \
  http://localhost:3000/api/protege

# 8. Autorisation : jvermot (employé) sur /api/direction -> 403
curl -i -H "Authorization: Bearer LE_TOKEN_JVERMOT" \
  http://localhost:3000/api/direction

# 9. mchronos (mot de passe patron789) sur /api/direction -> 200
```

Le moment clé : l'étape 7 (le sceau rejette la moindre falsification)
et le duo 401/403 des étapes 2 et 8 (authentification vs autorisation).

## Comptes de démonstration

| Utilisateur | Mot de passe | Rôle       |
|-------------|--------------|------------|
| jvermot     | compta123    | employé    |
| cdubois     | audit456     | employé    |
| mchronos    | patron789    | directeur  |
