// ============================================================
// Démo séance 5 : JWT en pratique
// Un mini-serveur INDÉPENDANT de tout le reste, pour montrer le
// mécanisme pur : délivrance d'un jeton au login, vérification
// du sceau à chaque requête protégée.
//
// Lancement :  npm install  puis  node server.js
// Scénario de démo : voir README.md (les curl sont prêts).
// ============================================================

const express = require('express');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());
app.use(express.static('public'));

// Le SECRET ne quitte jamais le serveur. En production : variable
// d'environnement, longue et aléatoire. Ici : lisible pour la démo.
const SECRET = 'chronos-secret-2026';

// Trois employés fictifs (en vrai : mots de passe HACHÉS en base,
// jamais en clair... mais ça, c'est le métier du Portier, séance 6).
const EMPLOYES = {
  jvermot: { motDePasse: 'compta123', role: 'employe' },
  cdubois: { motDePasse: 'audit456', role: 'employe' },
  mchronos: { motDePasse: 'patron789', role: 'directeur' },
};

// ---------- 1. Le guichet : prouver son identité UNE fois ----------
app.post('/api/login', (req, res) => {
  const { username, motDePasse } = req.body;
  const employe = EMPLOYES[username];

  if (!employe || employe.motDePasse !== motDePasse) {
    return res.status(401).json({ erreur: 'Identifiants invalides' });
  }

  // Identité prouvée : on délivre la carte (signée, avec expiration)
  const token = jwt.sign(
    { utilisateur: username, role: employe.role },
    SECRET,
    { expiresIn: '8h' }
  );
  res.json({ token });
});

// ---------- 2. Le sceau : vérifié à CHAQUE requête ----------
function verifierJeton(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  try {
    req.utilisateur = jwt.verify(token, SECRET); // recalcule et compare le sceau
    next();
  } catch (err) {
    res.status(401).json({ erreur: 'Jeton absent, invalide ou expiré' });
  }
}

// Endpoint public : aucune carte demandée
app.get('/api/public', (req, res) => {
  res.json({ message: 'Bonjour, inconnu. Ceci est public.' });
});

// Endpoint protégé : carte obligatoire
app.get('/api/protege', verifierJeton, (req, res) => {
  res.json({
    message: `Bonjour ${req.utilisateur.utilisateur} ! Vous êtes authentifié.`,
    contenuDuJeton: req.utilisateur,
  });
});

// Endpoint réservé : carte obligatoire ET bon rôle (l'autorisation !)
app.get('/api/direction', verifierJeton, (req, res) => {
  if (req.utilisateur.role !== 'directeur') {
    // Authentifié (on sait QUI c'est) mais pas autorisé : 403, pas 401
    return res.status(403).json({ erreur: 'Réservé à la direction' });
  }
  res.json({ message: `Bienvenue au conseil, ${req.utilisateur.utilisateur}.` });
});

app.listen(3000, () => {
  console.log('Démo JWT sur http://localhost:3000');
  console.log('Décodeur de jetons : http://localhost:3000/decodeur.html');
});
